#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int medalla, sinMedalla = 0, oro = 0, plata = 0, bronce = 0;

    srand(time(0));

    for (int i = 1; i <= 50; i++) {
        medalla = rand() % 4;

        cout << "Prueba " << i << ": " << medalla << endl;

        switch (medalla) {
            case 0: sinMedalla++; break;
            case 1: oro++; break;
            case 2: plata++; break;
            case 3: bronce++; break;
        }
    }

    cout << "\nREPORTE FINAL " << endl;
    cout << "Pruebas sin medalla: " << sinMedalla << endl;
    cout << "Medallas de oro: " << oro << endl;
    cout << "Medallas de plata: " << plata << endl;
    cout << "Medallas de bronce: " << bronce << endl;
    cout << "Total de medallas de EEUU: "
         << oro + plata + bronce << endl;

    return 0;
}

